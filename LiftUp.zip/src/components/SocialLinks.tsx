import React from 'react';
import { IonList, IonItem, IonLabel, IonIcon } from '@ionic/react';
import { logoFacebook, logoTwitter, logoInstagram, logoLinkedin, codeWorking } from 'ionicons/icons';

const SocialLinks: React.FC = () => {
  // Aquí puedes agregar las URLs de las redes sociales y proyectos del usuario
  const userLinks = {
    facebook: "https://www.facebook.com/usuario",
    twitter: "https://www.twitter.com/usuario",
    instagram: "https://www.instagram.com/usuario",
    linkedin: "https://www.linkedin.com/in/usuario",
    project: "https://www.proyecto.com/usuario"
  };

  return (
    <IonList>
      <IonItem button onClick={() => window.open(userLinks.facebook, '_blank')}>
        <IonIcon icon={logoFacebook} slot="start" />
        <IonLabel>Facebook: Perfil</IonLabel>
      </IonItem>
      <IonItem button onClick={() => window.open(userLinks.twitter, '_blank')}>
        <IonIcon icon={logoTwitter} slot="start" />
        <IonLabel>Twitter: Perfil</IonLabel>
      </IonItem>
      <IonItem button onClick={() => window.open(userLinks.instagram, '_blank')}>
        <IonIcon icon={logoInstagram} slot="start" />
        <IonLabel>Instagram: Perfil</IonLabel>
      </IonItem>
      <IonItem button onClick={() => window.open(userLinks.linkedin, '_blank')}>
        <IonIcon icon={logoLinkedin} slot="start" />
        <IonLabel>LinkedIn: Perfil</IonLabel>
      </IonItem>
      <IonItem button onClick={() => window.open(userLinks.project, '_blank')}>
        <IonIcon icon={codeWorking} slot="start" />
        <IonLabel>Proyecto: Ver Proyecto</IonLabel>
      </IonItem>
    </IonList>
  );
};

export default SocialLinks;
