import React, { useState } from 'react';
import { IonButton, IonInput, IonItem, IonLabel, IonText, IonContent } from '@ionic/react';
import { eye, eyeOff } from 'ionicons/icons';
import { IonIcon } from '@ionic/react';

const RegisterForm: React.FC = () => {
  const [username, setUsername] = useState('');
  const [rut, setRut] = useState('');
  const [email, setEmail] = useState('');
  const [region, setRegion] = useState('');
  const [comuna, setComuna] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const validateRut = (rut: string) => {
    const rutRegex = /^\d{1,8}-[0-9kK]$/;
    return rutRegex.test(rut);
  };

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePassword = (password: string) => {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+[\]{};':"\\|,.<>?])(?=.{10,})/;
    return passwordRegex.test(password);
  };

  const handleSubmit = () => {
    if (!username || !rut || !email || !region || !comuna || !password || !confirmPassword) {
      setError('Por favor, completa todos los campos.');
      return;
    }
    if (!validateRut(rut)) {
      setError('Formato de RUT inválido.');
      return;
    }
    if (!validateEmail(email)) {
      setError('Formato de correo electrónico inválido.');
      return;
    }
    if (!validatePassword(password)) {
      setError('La contraseña debe tener al menos 10 caracteres, incluyendo una mayúscula, una minúscula, un número y un carácter especial.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Las contraseñas no coinciden.');
      return;
    }
    if (!termsAccepted) {
      setError('Debes aceptar los términos y condiciones.');
      return;
    }

    // Lógica para registro
    console.log('Registro:', { username, rut, email, region, comuna, password });
  };

  return (
    <IonContent>
      <IonItem>
        <IonLabel position="stacked">Nombre de usuario</IonLabel>
        <IonInput value={username} onIonChange={e => setUsername(e.detail.value!)} />
      </IonItem>
      <IonItem>
        <IonLabel position="stacked">RUT</IonLabel>
        <IonInput value={rut} onIonChange={e => setRut(e.detail.value!)} />
      </IonItem>
      <IonItem>
        <IonLabel position="stacked">Correo Electrónico</IonLabel>
        <IonInput type="email" value={email} onIonChange={e => setEmail(e.detail.value!)} />
      </IonItem>
      <IonItem>
        <IonLabel position="stacked">Región</IonLabel>
        <IonInput value={region} onIonChange={e => setRegion(e.detail.value!)} />
      </IonItem>
      <IonItem>
        <IonLabel position="stacked">Comuna</IonLabel>
        <IonInput value={comuna} onIonChange={e => setComuna(e.detail.value!)} />
      </IonItem>
      <IonItem>
        <IonLabel position="stacked">Contraseña</IonLabel>
        <div style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
          <IonInput 
            type={showPassword ? 'text' : 'password'} 
            value={password} 
            onIonChange={e => setPassword(e.detail.value!)} 
            style={{ flex: 1 }} 
          />
          <IonButton onClick={() => setShowPassword(!showPassword)} fill="clear">
            <IonIcon icon={showPassword ? eyeOff : eye} />
          </IonButton>
        </div>
      </IonItem>
      <IonItem>
        <IonLabel position="stacked">Confirmar Contraseña</IonLabel>
        <div style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
          <IonInput 
            type={showConfirmPassword ? 'text' : 'password'} 
            value={confirmPassword} 
            onIonChange={e => setConfirmPassword(e.detail.value!)} 
            style={{ flex: 1 }} 
          />
          <IonButton onClick={() => setShowConfirmPassword(!showConfirmPassword)} fill="clear">
            <IonIcon icon={showConfirmPassword ? eyeOff : eye} />
          </IonButton>
        </div>
      </IonItem>
      <IonItem>
        <IonLabel>
          <input
            type="checkbox"
            checked={termsAccepted}
            onChange={e => setTermsAccepted(e.target.checked)}
          />
          <span style={{ marginLeft: '8px' }}>Acepto los términos y condiciones</span>
        </IonLabel>
      </IonItem>
      {error && <IonText color="danger">{error}</IonText>}
      <IonButton expand="full" onClick={handleSubmit}>Registrarse</IonButton>
      <div style={{ display: 'flex', justifyContent: 'center', marginTop: '16px' }}>
        <IonButton fill="clear" onClick={() => console.log('¿Olvidaste tu contraseña?')}>
          ¿Olvidaste tu contraseña?
        </IonButton>
      </div>
    </IonContent>
  );
};

export default RegisterForm;
