import React from 'react';
import { IonHeader, IonToolbar, IonTitle, IonImg, IonButtons, IonButton, IonIcon } from '@ionic/react';
import { personCircle } from 'ionicons/icons'; // Icono de usuario
import logoLiftUp from '../assets/images/logoLiftUp.png'; // Ruta del logo
import { useHistory } from 'react-router-dom';
import './Header.css'; // Importa los estilos

const Header: React.FC = () => {
  const history = useHistory();

  return (
    <IonHeader>
      <IonToolbar>
        <IonImg 
          src={logoLiftUp} 
          alt="LiftUp Logo" 
          className="logo" 
          onClick={() => history.push('/home')} // Redirigir a la página de inicio al hacer clic
        />
        <IonButtons slot="end">
          <IonButton onClick={() => history.push('/login')}>
            <IonIcon icon={personCircle} size="large" />
          </IonButton>
        </IonButtons>
      </IonToolbar>
    </IonHeader>
  );
};

export default Header;
