import React, { useState } from 'react';
import { IonButton, IonInput, IonItem, IonLabel, IonText, IonContent } from '@ionic/react';

const LoginForm: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = () => {
    if (!username || !password) {
      setError('Por favor, completa todos los campos.');
      return;
    }
    // Lógica para inicio de sesión
    console.log('Inicio de sesión:', { username, password });
  };

  return (
    <IonContent>
      <IonItem>
        <IonLabel position="stacked">Nombre de usuario</IonLabel>
        <IonInput value={username} onIonChange={e => setUsername(e.detail.value!)} />
      </IonItem>
      <IonItem>
        <IonLabel position="stacked">Contraseña</IonLabel>
        <IonInput type="password" value={password} onIonChange={e => setPassword(e.detail.value!)} />
      </IonItem>
      {error && <IonText color="danger">{error}</IonText>}
      <IonButton expand="full" onClick={handleSubmit}>Iniciar sesión</IonButton>
    </IonContent>
  );
};

export default LoginForm;
