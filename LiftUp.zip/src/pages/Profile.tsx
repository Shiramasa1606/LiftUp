import React from 'react';
import { IonContent, IonPage, IonLabel, IonButton, IonAvatar, IonText, IonFooter } from '@ionic/react';
import Header from '../components/Header';
import SocialLinks from '../components/SocialLinks';
import Footer from '../components/Footer';

const Profile: React.FC = () => {
  const user = {
    name: "Juan Pérez",
    sponsoredProjects: 5,
    avatarUrl: "https://via.placeholder.com/150", // URL de un avatar de ejemplo
    bio: "Esta es la biografía del usuario. Aquí puedes escribir una breve descripción sobre el perfil, intereses, y otros detalles relevantes."
  };

  return (
    <IonPage>
      <Header />
      <div style={{ textAlign: 'center', margin: '16px 0', fontSize: '24px', fontWeight: 'bold' }}>
        {user.name}
      </div>
      <IonContent className="ion-padding">
        <IonButton expand="full" fill="clear" onClick={() => console.log('Editar Perfil')}>
          Editar Perfil
        </IonButton>
        <div style={{ display: 'flex', justifyContent: 'center', margin: '20px 0' }}>
          <IonAvatar style={{ width: '100px', height: '100px' }}>
            <img src={user.avatarUrl} alt="Avatar" />
          </IonAvatar>
        </div>
        <IonLabel style={{ display: 'block', textAlign: 'center', marginBottom: '10px' }}>
          Proyectos Patrocinados
        </IonLabel>
        <IonText style={{ display: 'block', textAlign: 'center', fontSize: '24px' }}>
          {user.sponsoredProjects}
        </IonText>

        {/* Sección de biografía */}
        <IonLabel style={{ display: 'block', textAlign: 'center', marginTop: '20px', fontWeight: 'bold' }}>
          Biografía
        </IonLabel>
        <IonText style={{ display: 'block', textAlign: 'center', marginTop: '10px' }}>
          {user.bio}
        </IonText>
        <SocialLinks />
      </IonContent>
      <IonFooter>
        <Footer />
      </IonFooter>
    </IonPage>
  );
};

export default Profile;
