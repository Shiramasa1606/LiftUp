import React, { useState } from 'react';
import { IonContent, IonPage, IonSegment, IonSegmentButton, IonLabel, IonFooter } from '@ionic/react';
import LoginForm from '../components/LoginForm';
import RegisterForm from '../components/RegisterForm';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Auth: React.FC = () => {
  const [mode, setMode] = useState<'login' | 'register'>('login');

  const handleSegmentChange = (e: CustomEvent) => {
    setMode(e.detail.value as 'login' | 'register'); // Asegúrate de hacer la conversión de tipo
  };

  return (
    <IonPage>
      <Header />
      <IonSegment value={mode} onIonChange={handleSegmentChange}>
        <IonSegmentButton value="login">
          <IonLabel>Iniciar Sesión</IonLabel>
        </IonSegmentButton>
        <IonSegmentButton value="register">
          <IonLabel>Registrarse</IonLabel>
        </IonSegmentButton>
      </IonSegment>

      <IonContent>
        {mode === 'login' ? <LoginForm /> : <RegisterForm />}
      </IonContent>
      <IonFooter>
        <Footer />
      </IonFooter>
    </IonPage>
  );
};

export default Auth;
