import { IonContent, IonPage, IonFooter } from '@ionic/react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import FooterSections from '../components/FooterSections';

import './Home.css';

const Home: React.FC = () => {
  return (
    <IonPage>
      <Header />
      <IonContent fullscreen>
        <div className="content-padding">
          <h2>Lorem Ipsum</h2>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
            Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
          </p>
          {[...Array(20)].map((_, index) => (
            <p key={index}>Este es un párrafo de prueba número {index + 1}.</p>
          ))}
        </div>
        <FooterSections />
      </IonContent>
      <IonFooter>
        <Footer />
      </IonFooter>
    </IonPage>
  );
};

export default Home;
